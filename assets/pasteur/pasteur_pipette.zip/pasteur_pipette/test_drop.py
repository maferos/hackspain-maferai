"""Drop test: loads the pipette on a plane, simulates 2 s, prints resting pose."""
import mujoco, numpy as np, os
here = os.path.dirname(os.path.abspath(__file__))
xml = open(os.path.join(here, "pasteur_pipette.xml")).read()
xml = xml.replace('<worldbody>', '<worldbody>\n    <geom name="floor" type="plane" size="1 1 0.1" friction="0.7"/>\n    <light pos="0 0 1"/>')
xml = xml.replace('meshdir="meshes"', f'meshdir="{os.path.join(here, "meshes")}"')
m = mujoco.MjModel.from_xml_string(xml)
d = mujoco.MjData(m)
d.qpos[2] = 0.05  # 5 cm above the floor
for _ in range(int(2.0 / m.opt.timestep)):
    mujoco.mj_step(m, d)
print("rest pos", np.round(d.qpos[:3], 4), "quat", np.round(d.qpos[3:7], 3),
      "contacts", d.ncon, "|v|", np.linalg.norm(d.qvel[:3]).round(5))
