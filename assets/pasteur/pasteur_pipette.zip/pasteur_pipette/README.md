# Pasteur pipette 3 ml — sim-ready 3D asset

Graduated LDPE transfer pipette (155 mm, bulb Ø13.2 mm, 0.5 ml graduation ridges, embossed 1/2/3).
Generated procedurally in Blender, no third-party licence (same approach as `reagent_jars_kit`).

## Files
| File | Use |
|---|---|
| `pasteur_pipette.blend` | Blender 4.0 source (visual + `collision` collection, camera/lights) |
| `pasteur_pipette.glb` | visual + collision nodes, glTF extras (`capacity_ml`, `mass_kg`, …) |
| `meshes/pipette_visual.obj` | 6.2k tris, smooth, +Z up |
| `meshes/pipette_col_{bulb,stem_upper,stem_lower}.obj` | 3 convex pieces, 60–290 tris |
| `pasteur_pipette.xml` | **MuJoCo** MJCF (tested, mujoco 3.13: loads, 1.2 g, rests stably on a plane) |
| `pasteur_pipette.urdf` | URDF with inertia, for Isaac Lab `UrdfConverter` or any URDF loader |
| `isaaclab_pasteur_pipette.py` | **Isaac Lab** `RigidObjectCfg` + one-shot URDF→USD conversion |
| `generate_pasteur_pipette.py` | regenerate / change size (`TOTAL_LEN`, `BULB_R`, `GRADS`, `MASS_KG`) |
| `test_drop.py` | MuJoCo drop test |

## Conventions
Metres, origin at the **tip**, +Z towards the bulb (same "bottom-centre" convention as the jars).
Sites in the MJCF: `pipette_tip` (0,0,0), `pipette_grasp` (z=0.125, on the bulb), `pipette_bulb` (z=0.135).
To lay it flat use `quat="0.7071068 0 0.7071068 0"` (tip along +X).

## MuJoCo
```xml
<include file="pasteur_pipette.xml"/>
```
or copy the `<asset>`, `<default>` and `<body>` blocks into your scene (set `meshdir`).
Collision group 3, visual group 2; visual geoms have `contype/conaffinity = 0`.

## Isaac Lab
```python
from isaaclab_pasteur_pipette import PASTEUR_PIPETTE_CFG, build_usd
build_usd()                                    # once: meshes -> usd/pasteur_pipette.usd
pipette = PASTEUR_PIPETTE_CFG.replace(prim_path="{ENV_REGEX_NS}/Pipette")
```
Alternatively `MjcfConverter` on `pasteur_pipette.xml`, or export `.usd` from Blender ≥ 4.1
(the Ubuntu 4.0 build used here lacks the USD exporter) and add `RigidBodyAPI`/`CollisionAPI` in Isaac Sim.

## Regenerate
```
blender -b -P generate_pasteur_pipette.py -- --out .
```
