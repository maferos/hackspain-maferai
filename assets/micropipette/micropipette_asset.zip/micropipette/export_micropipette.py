"""
Build the micropipette and write every runtime asset:
  meshes/<part>.stl / .obj        one file per part (MuJoCo, URDF)
  meshes/link_<link>.obj          merged visual per link (with materials)
  micropipette.glb                whole model, glTF +Y up, metres
  micropipette.xml                MuJoCo MJCF (free body + plunger/ejector slide joints)
  micropipette.urdf               URDF (Isaac Lab UrdfConverter, ROS)
  micropipette.usd                USD with UsdPhysics rigid body / colliders / prismatic joints
  preview.png                     quick render
Run:  python export_micropipette.py [out_dir]
"""
import os, sys, json
import numpy as np
import trimesh
from pipette_geometry import build_parts, MATERIALS, JOINTS, LINK_MASS, D, TOTAL_LENGTH

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
MESH = os.path.join(OUT, "meshes"); os.makedirs(MESH, exist_ok=True)

parts = build_parts()
meshes, links = {}, {"body": [], "plunger": [], "ejector": []}
for name, v, f, mat, link in parts:
    m = trimesh.Trimesh(v, f, process=True)
    m.fix_normals()
    rgba = np.array(MATERIALS[mat]["rgba"]) * 255
    m.visual = trimesh.visual.TextureVisuals(material=trimesh.visual.material.PBRMaterial(
        name=mat, baseColorFactor=rgba.astype(np.uint8), roughnessFactor=MATERIALS[mat]["rough"], metallicFactor=0.0))
    m.metadata["name"] = name
    meshes[name] = (m, mat, link)
    links[link].append(name)
    m.export(os.path.join(MESH, f"{name}.stl"))
    m.export(os.path.join(MESH, f"{name}.obj"))

# ---------------- per-link merged OBJ with .mtl (nice for URDF / Isaac)
for link, names in links.items():
    scene = trimesh.Scene()
    for n in names:
        scene.add_geometry(meshes[n][0].copy(), node_name=n, geom_name=n)
    scene.export(os.path.join(MESH, f"link_{link}.obj"))

# ---------------- GLB (whole model, Z-up -> Y-up)
scene = trimesh.Scene()
R = trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0])
for link in links:
    scene.graph.update(frame_to=link, frame_from=scene.graph.base_frame, matrix=np.eye(4))
for link, names in links.items():
    for n in names:
        m, mat, _ = meshes[n]
        scene.add_geometry(m.copy(), node_name=n, geom_name=n, parent_node_name=link)
scene.apply_transform(R)
scene.metadata["extras"] = dict(units="m", origin="tip bottom-centre", total_length_m=TOTAL_LENGTH,
                                mass_kg=sum(LINK_MASS.values()), joints=JOINTS)
scene.export(os.path.join(OUT, "micropipette.glb"))

# ---------------- collision primitives (analytic, fast, shared by MJCF/URDF/USD)
d = D
zb0, zb1 = d["body_z0"], d["body_z0"] + d["body_len"]
COLL = {
    "body": [
        dict(type="box", pos=(0, 0, (zb0 + zb1) / 2), size=((d["body_w0"] + d["body_w1"]) / 4, (d["body_d0"] + d["body_d1"]) / 4, d["body_len"] / 2)),
        dict(type="capsule", fromto=(0, 0, d["tip_len"], 0, 0, zb0), radius=d["shaft_r1"]),
        dict(type="capsule", fromto=(0, 0, 0.0005, 0, 0, d["tip_len"] + 0.002), radius=d["tip_r1"]),
        dict(type="cylinder", pos=(0, 0, zb0 - 0.006), size=(d["collar_r1"], 0.006)),
        dict(type="box", pos=(-d["body_w1"] / 2 - 0.006, 0, zb1 - 0.008), size=(0.009, d["hook_w"] / 2, 0.012)),  # hook
        dict(type="box", pos=(d["ejector_x"] - 0.001, 0, (zb0 + d["ejector_btn_z"]) / 2 - 0.02), size=(0.0035, 0.005, (d["ejector_btn_z"] - zb0 - 0.06) / 2)),
    ],
    "plunger": [
        dict(type="cylinder", pos=(d["plunger_x"], 0, zb1 + 0.004 + d["plunger_len"] + d["button_h"] / 2), size=(d["button_r"], d["button_h"] / 2)),
        dict(type="cylinder", pos=(d["plunger_x"], 0, zb1 + 0.004 + d["plunger_len"] / 2), size=(d["plunger_r"], d["plunger_len"] / 2 + 0.006)),
    ],
    "ejector": [
        dict(type="cylinder", pos=(d["ejector_x"] + 0.0025, 0, d["ejector_btn_z"] + d["ejector_btn_h"] / 2), size=(d["ejector_btn_r"], d["ejector_btn_h"] / 2)),
        dict(type="cylinder", pos=(0, 0, (d["ejector_sleeve_z0"] + d["ejector_sleeve_z1"]) / 2), size=(d["ejector_sleeve_r"], (d["ejector_sleeve_z1"] - d["ejector_sleeve_z0"]) / 2)),
    ],
}

# ---------------- MJCF
def fmt(t): return " ".join(f"{x:.5f}" for x in t)
rgba = {k: fmt(v["rgba"]) for k, v in MATERIALS.items()}
L = ['<mujoco model="micropipette">',
     '  <compiler angle="radian" meshdir="meshes" autolimits="true"/>',
     '  <option gravity="0 0 -9.81"/>',
     '  <default>',
     '    <default class="pipette_visual"><geom type="mesh" contype="0" conaffinity="0" group="2" mass="0"/></default>',
     '    <default class="pipette_collision"><geom group="3" condim="4" friction="0.9 0.005 0.0001" solref="0.005 1" rgba="0.8 0.3 0.3 0.3"/></default>',
     '  </default>',
     '  <asset>']
for k, v in MATERIALS.items():
    L.append(f'    <material name="pip_{k}" rgba="{rgba[k]}" specular="0.3" shininess="{1 - v["rough"]:.2f}"/>')
for n in meshes:
    L.append(f'    <mesh name="pip_{n}" file="{n}.stl"/>')
L.append('  </asset>')
L.append('  <worldbody>')
L.append('    <body name="micropipette" pos="0 0 0.05">')
L.append('      <freejoint name="micropipette_free"/>')
L.append('      <site name="pipette_grip" pos="0 0 %.4f" size="0.004" rgba="0 1 0 0.5"/>' % ((zb0 + zb1) / 2))
L.append('      <site name="pipette_tip" pos="0 0 0" size="0.002" rgba="1 0 0 0.5"/>')

def emit_link(link, indent):
    sp = " " * indent
    L.append(f'{sp}<inertial pos="{fmt(np.mean([c["pos"] if "pos" in c else np.array(c["fromto"]).reshape(2,3).mean(0) for c in COLL[link]], axis=0))}" mass="{LINK_MASS[link]}" diaginertia="{" ".join(f"{x:.3e}" for x in _inertia(link))}"/>')
    for n in links[link]:
        L.append(f'{sp}<geom class="pipette_visual" mesh="pip_{n}" material="pip_{meshes[n][1]}" name="vis_{n}"/>')
    for i, c in enumerate(COLL[link]):
        if c["type"] == "capsule":
            L.append(f'{sp}<geom class="pipette_collision" type="capsule" fromto="{fmt(c["fromto"])}" size="{c["radius"]:.5f}" name="col_{link}_{i}"/>')
        else:
            L.append(f'{sp}<geom class="pipette_collision" type="{c["type"]}" pos="{fmt(c["pos"])}" size="{fmt(c["size"])}" name="col_{link}_{i}"/>')

def _inertia(link):
    # rough: treat link as its bounding box
    pts = np.vstack([meshes[n][0].vertices for n in links[link]])
    ext = pts.max(0) - pts.min(0); m = LINK_MASS[link]
    return (m / 12 * (ext[1] ** 2 + ext[2] ** 2), m / 12 * (ext[0] ** 2 + ext[2] ** 2), m / 12 * (ext[0] ** 2 + ext[1] ** 2))

emit_link("body", 6)
for jn in ("plunger", "ejector"):
    j = JOINTS[jn]
    L.append(f'      <body name="pipette_{jn}" pos="0 0 0">')
    L.append(f'        <joint name="pipette_{jn}_slide" type="slide" axis="0 0 1" range="{j["range"][0]} {j["range"][1]}" '
             f'stiffness="{j["stiffness"]}" damping="{j["damping"]}" springref="0" armature="0.0005"/>')
    emit_link(jn, 8)
    L.append('      </body>')
L += ['    </body>', '  </worldbody>',
      '  <actuator>',
      '    <position name="pipette_plunger_act" joint="pipette_plunger_slide" kp="600" ctrlrange="-0.014 0"/>',
      '    <position name="pipette_ejector_act" joint="pipette_ejector_slide" kp="800" ctrlrange="-0.008 0"/>',
      '  </actuator>',
      '  <contact>',
      '    <exclude body1="micropipette" body2="pipette_plunger"/>',
      '    <exclude body1="micropipette" body2="pipette_ejector"/>',
      '    <exclude body1="pipette_plunger" body2="pipette_ejector"/>',
      '  </contact>',
      '</mujoco>']
open(os.path.join(OUT, "micropipette.xml"), "w").write("\n".join(L))

# ---------------- URDF
U = ['<?xml version="1.0"?>', '<robot name="micropipette">']
for k, v in MATERIALS.items():
    U.append(f'  <material name="pip_{k}"><color rgba="{rgba[k]}"/></material>')

def urdf_link(link):
    I = _inertia(link); c = COLL[link]
    com = np.mean([x["pos"] if "pos" in x else np.array(x["fromto"]).reshape(2, 3).mean(0) for x in c], axis=0)
    U.append(f'  <link name="pipette_{link}">')
    U.append(f'    <inertial><origin xyz="{fmt(com)}"/><mass value="{LINK_MASS[link]}"/>'
             f'<inertia ixx="{I[0]:.3e}" iyy="{I[1]:.3e}" izz="{I[2]:.3e}" ixy="0" ixz="0" iyz="0"/></inertial>')
    for n in links[link]:
        U.append(f'    <visual name="{n}"><geometry><mesh filename="meshes/{n}.obj"/></geometry><material name="pip_{meshes[n][1]}"/></visual>')
    for x in c:
        if x["type"] == "box":
            U.append(f'    <collision><origin xyz="{fmt(x["pos"])}"/><geometry><box size="{fmt(np.array(x["size"]) * 2)}"/></geometry></collision>')
        elif x["type"] == "cylinder":
            U.append(f'    <collision><origin xyz="{fmt(x["pos"])}"/><geometry><cylinder radius="{x["size"][0]:.5f}" length="{x["size"][1] * 2:.5f}"/></geometry></collision>')
        else:  # capsule -> cylinder in URDF
            a, b = np.array(x["fromto"]).reshape(2, 3)
            U.append(f'    <collision><origin xyz="{fmt((a + b) / 2)}"/><geometry><cylinder radius="{x["radius"]:.5f}" length="{np.linalg.norm(b - a):.5f}"/></geometry></collision>')
    U.append('  </link>')

urdf_link("body")
for jn in ("plunger", "ejector"):
    urdf_link(jn); j = JOINTS[jn]
    U.append(f'  <joint name="pipette_{jn}_slide" type="prismatic"><parent link="pipette_body"/><child link="pipette_{jn}"/>'
             f'<axis xyz="0 0 1"/><limit lower="{j["range"][0]}" upper="{j["range"][1]}" effort="20" velocity="0.5"/>'
             f'<dynamics damping="{j["damping"]}"/></joint>')
U.append('</robot>')
open(os.path.join(OUT, "micropipette.urdf"), "w").write("\n".join(U))

# ---------------- USD (usd-core) for Isaac Lab / Isaac Sim
try:
    from pxr import Usd, UsdGeom, UsdPhysics, UsdShade, Sdf, Gf, Vt, PhysxSchema
    HAVE_PHYSX = True
except ImportError:
    from pxr import Usd, UsdGeom, UsdPhysics, UsdShade, Sdf, Gf, Vt
    HAVE_PHYSX = False

stage = Usd.Stage.CreateNew(os.path.join(OUT, "micropipette.usd"))
UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z); UsdGeom.SetStageMetersPerUnit(stage, 1.0)
root = UsdGeom.Xform.Define(stage, "/micropipette"); stage.SetDefaultPrim(root.GetPrim())
Usd.ModelAPI(root).SetKind("component")
UsdPhysics.ArticulationRootAPI.Apply(root.GetPrim())
mats = {}
for k, v in MATERIALS.items():
    mp = UsdShade.Material.Define(stage, f"/micropipette/Looks/pip_{k}")
    sh = UsdShade.Shader.Define(stage, f"/micropipette/Looks/pip_{k}/Shader"); sh.CreateIdAttr("UsdPreviewSurface")
    sh.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*v["rgba"][:3]))
    sh.CreateInput("roughness", Sdf.ValueTypeNames.Float).Set(v["rough"]); sh.CreateInput("metallic", Sdf.ValueTypeNames.Float).Set(0.0)
    mp.CreateSurfaceOutput().ConnectToSource(sh.ConnectableAPI(), "surface"); mats[k] = mp

def usd_link(link):
    lx = UsdGeom.Xform.Define(stage, f"/micropipette/{link}"); p = lx.GetPrim()
    UsdPhysics.RigidBodyAPI.Apply(p); mass = UsdPhysics.MassAPI.Apply(p); mass.CreateMassAttr(LINK_MASS[link])
    for n in links[link]:
        m, mat, _ = meshes[n]
        mesh = UsdGeom.Mesh.Define(stage, f"/micropipette/{link}/visuals/{n}")
        mesh.CreatePointsAttr(Vt.Vec3fArray([Gf.Vec3f(*map(float, x)) for x in m.vertices]))
        mesh.CreateFaceVertexCountsAttr(Vt.IntArray([3] * len(m.faces)))
        mesh.CreateFaceVertexIndicesAttr(Vt.IntArray(m.faces.flatten().tolist()))
        mesh.CreateNormalsAttr(Vt.Vec3fArray([Gf.Vec3f(*map(float, x)) for x in m.vertex_normals])); mesh.SetNormalsInterpolation("vertex")
        mesh.CreateSubdivisionSchemeAttr("none")
        UsdShade.MaterialBindingAPI.Apply(mesh.GetPrim()).Bind(mats[mat])
    for i, c in enumerate(COLL[link]):
        path = f"/micropipette/{link}/collisions/col_{i}"
        if c["type"] == "box":
            g = UsdGeom.Cube.Define(stage, path); g.CreateSizeAttr(1.0)
            xf = UsdGeom.Xformable(g); xf.AddTranslateOp().Set(Gf.Vec3d(*map(float, c["pos"]))); xf.AddScaleOp().Set(Gf.Vec3f(*[float(s) * 2 for s in c["size"]]))
        elif c["type"] == "cylinder":
            g = UsdGeom.Cylinder.Define(stage, path); g.CreateRadiusAttr(float(c["size"][0])); g.CreateHeightAttr(float(c["size"][1]) * 2); g.CreateAxisAttr("Z")
            UsdGeom.Xformable(g).AddTranslateOp().Set(Gf.Vec3d(*map(float, c["pos"])))
        else:
            a, b = np.array(c["fromto"]).reshape(2, 3); h = float(np.linalg.norm(b - a))
            g = UsdGeom.Capsule.Define(stage, path); g.CreateRadiusAttr(float(c["radius"])); g.CreateHeightAttr(h); g.CreateAxisAttr("Z")
            UsdGeom.Xformable(g).AddTranslateOp().Set(Gf.Vec3d(*map(float, (a + b) / 2)))
        g.CreatePurposeAttr(UsdGeom.Tokens.guide)
        UsdPhysics.CollisionAPI.Apply(g.GetPrim())
    return p

body = usd_link("body")
for jn in ("plunger", "ejector"):
    child = usd_link(jn); j = JOINTS[jn]
    pj = UsdPhysics.PrismaticJoint.Define(stage, f"/micropipette/joints/{jn}_slide")
    pj.CreateBody0Rel().SetTargets([body.GetPath()]); pj.CreateBody1Rel().SetTargets([child.GetPath()])
    pj.CreateAxisAttr("Z"); pj.CreateLowerLimitAttr(j["range"][0]); pj.CreateUpperLimitAttr(j["range"][1])
    drv = UsdPhysics.DriveAPI.Apply(pj.GetPrim(), "linear")
    drv.CreateTypeAttr("force"); drv.CreateStiffnessAttr(j["stiffness"]); drv.CreateDampingAttr(j["damping"]); drv.CreateTargetPositionAttr(0.0)
    drv.CreateMaxForceAttr(20.0)
stage.GetRootLayer().Save()

# ---------------- preview render (matplotlib, no GPU needed)
try:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    fig = plt.figure(figsize=(9, 8), dpi=120)
    views = [(20, -60, "3/4 front"), (0, -90, "front (display)"), (0, 0, "side (+X ejector)")]
    for k, (el, az, ttl) in enumerate(views):
        ax = fig.add_subplot(1, 3, k + 1, projection="3d")
        for n, (m, mat, _) in meshes.items():
            col = MATERIALS[mat]["rgba"][:3]
            pc = Poly3DCollection(m.vertices[m.faces], facecolor=col, edgecolor="none", linewidth=0)
            pc.set_alpha(1.0); ax.add_collection3d(pc)
        r = 0.045
        ax.set_xlim(-r, r); ax.set_ylim(-r, r); ax.set_zlim(-0.005, TOTAL_LENGTH + 0.005)
        ax.set_box_aspect((2 * r, 2 * r, TOTAL_LENGTH + 0.01)); ax.view_init(el, az); ax.set_axis_off(); ax.set_title(ttl, fontsize=9)
    fig.patch.set_facecolor("#e9ecef"); plt.tight_layout()
    plt.savefig(os.path.join(OUT, "preview.png")); print("preview.png written")
except Exception as e:
    print("preview skipped:", e)

json.dump(dict(units="m", up="Z (GLB is Y-up)", origin="tip bottom-centre", total_length_m=round(TOTAL_LENGTH, 4),
               links={k: dict(mass_kg=LINK_MASS[k], parts=v) for k, v in links.items()}, joints=JOINTS,
               grip_site_z=(zb0 + zb1) / 2), open(os.path.join(OUT, "micropipette_meta.json"), "w"), indent=2)
print("done ->", OUT)
