"""
Parametric single-channel adjustable micropipette (5-50 µL class, DLAB TopPette /
Eppendorf Research style).  Pure numpy so the same file works inside Blender (bpy)
and in a plain Python env (trimesh).

Units: metres.  Z up.  Origin at the tip-cone end (bottom-centre).
X+ = side with the tip-ejector button,  Y- = front (display window side).

Each part is returned as (name, verts[N,3], faces[M,3], material_key, group).
group: 'body' | 'plunger' | 'ejector'  -> which rigid link it belongs to.
"""
import numpy as np

# ------------------------------------------------------------------ dimensions
D = dict(
    tip_len=0.012,      tip_r0=0.0024, tip_r1=0.0036,       # dark nose cone
    shaft_len=0.078,    shaft_r0=0.0036, shaft_r1=0.0058,   # blue shaft
    collar_len=0.026,   collar_r1=0.0112,                   # blue cone to body
    body_z0=0.116,      body_len=0.105,                     # white handle
    body_w0=0.024, body_w1=0.030,  body_d0=0.020, body_d1=0.024, body_round=0.006,
    plunger_x=0.003,    plunger_r=0.0040, plunger_len=0.030,
    button_r=0.0085,    button_h=0.0085,
    ejector_x=0.0165,   ejector_r=0.0028,
    ejector_btn_r=0.0075, ejector_btn_h=0.006, ejector_btn_z=0.232,
    ejector_sleeve_r=0.0068, ejector_sleeve_z0=0.066, ejector_sleeve_z1=0.094,
    hook_w=0.016, hook_t=0.007, hook_reach=0.024,
    disp_w=0.011, disp_h=0.026, disp_z=0.148, disp_depth=0.0012,
)

MATERIALS = {
    "white":   dict(rgba=(0.93, 0.93, 0.92, 1.0), rough=0.45),
    "blue":    dict(rgba=(0.41, 0.58, 0.87, 1.0), rough=0.40),
    "dark":    dict(rgba=(0.06, 0.06, 0.07, 1.0), rough=0.35),
    "display": dict(rgba=(0.02, 0.02, 0.02, 1.0), rough=0.15),
}

# ------------------------------------------------------------------ primitives
def _ring(r, z, n, cx=0.0, cy=0.0):
    a = np.linspace(0, 2 * np.pi, n, endpoint=False)
    return np.c_[cx + r * np.cos(a), cy + r * np.sin(a), np.full(n, z)]


def lathe(profile, n=48, cx=0.0, cy=0.0, cap=True):
    """profile: list of (r, z) from bottom to top -> closed surface of revolution."""
    rings = [_ring(r, z, n, cx, cy) for r, z in profile]
    verts = np.vstack(rings)
    faces = []
    k = len(rings)
    for i in range(k - 1):
        for j in range(n):
            a, b = i * n + j, i * n + (j + 1) % n
            c, d = a + n, b + n
            faces += [[a, b, d], [a, d, c]]
    if cap:
        vb = len(verts); verts = np.vstack([verts, [[cx, cy, profile[0][1]]]])
        faces += [[vb, (j + 1) % n, j] for j in range(n)]
        vt = len(verts); verts = np.vstack([verts, [[cx, cy, profile[-1][1]]]])
        base = (k - 1) * n
        faces += [[vt, base + j, base + (j + 1) % n] for j in range(n)]
    return verts, np.array(faces)


def rounded_rect(w, d, r, n_corner=6):
    """2D outline (x,y) of a rounded rectangle centred at origin, CCW."""
    pts = []
    cx, cy = w / 2 - r, d / 2 - r
    corners = [(cx, cy, 0), (-cx, cy, np.pi / 2), (-cx, -cy, np.pi), (cx, -cy, 3 * np.pi / 2)]
    for x0, y0, a0 in corners:
        for t in np.linspace(a0, a0 + np.pi / 2, n_corner, endpoint=False):
            pts.append((x0 + r * np.cos(t), y0 + r * np.sin(t)))
    return np.array(pts)


def loft(sections, cap=True):
    """sections: list of [N,3] rings with identical N -> lofted closed mesh."""
    n = len(sections[0]); verts = np.vstack(sections); faces = []
    for i in range(len(sections) - 1):
        for j in range(n):
            a, b = i * n + j, i * n + (j + 1) % n
            faces += [[a, b, b + n], [a, b + n, a + n]]
    if cap:
        for idx, flip in ((0, True), (len(sections) - 1, False)):
            c = sections[idx].mean(axis=0); vi = len(verts)
            verts = np.vstack([verts, c]); base = idx * n
            for j in range(n):
                tri = [vi, base + j, base + (j + 1) % n]
                faces.append(tri[::-1] if flip else tri)
    return verts, np.array(faces)


def box(cx, cy, cz, sx, sy, sz):
    s = np.array([sx, sy, sz]) / 2
    v = np.array([[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
                  [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]]) * s + [cx, cy, cz]
    f = [[0, 2, 1], [0, 3, 2], [4, 5, 6], [4, 6, 7], [0, 1, 5], [0, 5, 4],
         [1, 2, 6], [1, 6, 5], [2, 3, 7], [2, 7, 6], [3, 0, 4], [3, 4, 7]]
    return v, np.array(f)


def sweep_arc(profile2d, centre, radius, a0, a1, n=14, plane="xz"):
    """Sweep a 2D closed profile (u along arc-normal, v along arc axis) around an arc
    in the XZ plane about `centre` (x,z). Used for the finger hook."""
    secs = []
    for t in np.linspace(a0, a1, n):
        radial = np.array([np.cos(t), 0.0, np.sin(t)])
        axis = np.array([0.0, 1.0, 0.0])
        p = np.array([centre[0], 0.0, centre[1]]) + radius * radial
        secs.append(np.array([p + u * radial + v * axis for u, v in profile2d]))
    return loft(secs)


# ------------------------------------------------------------------ parts
def build_parts():
    d = D
    parts = []

    # --- nose cone (dark)
    z0 = 0.0
    parts.append(("tip_cone", *lathe([(d["tip_r0"], z0), (d["tip_r1"], z0 + d["tip_len"])], 40), "dark", "body"))

    # --- blue shaft (slight taper) + small step ring at the top
    z1 = d["tip_len"]; z2 = z1 + d["shaft_len"]
    parts.append(("shaft", *lathe([(d["tip_r1"], z1 - 0.0005), (d["shaft_r0"], z1 + 0.003),
                                    (d["shaft_r1"], z2)], 48), "blue", "body"))

    # --- collar cone up to body
    z3 = d["body_z0"]
    parts.append(("collar", *lathe([(d["shaft_r1"] + 0.0004, z2 - 0.001), (d["collar_r1"], z3 - 0.004),
                                     (d["collar_r1"], z3 + 0.002)], 48), "blue", "body"))

    # --- white handle body: lofted tapered rounded rectangle with a domed top
    zb0, zb1 = d["body_z0"], d["body_z0"] + d["body_len"]
    secs = []
    for t in np.linspace(0, 1, 6):
        w = d["body_w0"] + (d["body_w1"] - d["body_w0"]) * t
        dp = d["body_d0"] + (d["body_d1"] - d["body_d0"]) * t
        z = zb0 + (zb1 - zb0) * t
        rr = rounded_rect(w, dp, d["body_round"])
        secs.append(np.c_[rr, np.full(len(rr), z)])
    # rounded shoulder at the top
    for k, (sc, dz) in enumerate([(0.96, 0.002), (0.85, 0.0038), (0.62, 0.0052)]):
        rr = rounded_rect(d["body_w1"] * sc, d["body_d1"] * sc, d["body_round"] * sc)
        secs.append(np.c_[rr, np.full(len(rr), zb1 + dz)])
    parts.append(("body", *loft(secs), "white", "body"))

    # --- finger hook: sweeps from the body top on the -X side, curling outward/down
    hook_prof = [(-d["hook_t"] / 2, -d["hook_w"] / 2), (d["hook_t"] / 2, -d["hook_w"] / 2),
                 (d["hook_t"] / 2, d["hook_w"] / 2), (-d["hook_t"] / 2, d["hook_w"] / 2)]
    hc = (-d["body_w1"] / 2 + 0.004, zb1 - d["hook_reach"] * 0.15)
    parts.append(("finger_hook", *sweep_arc(hook_prof, hc, d["hook_reach"] * 0.62, np.pi * 0.5, np.pi * 1.32, 16),
                  "white", "body"))

    # --- display window (black, slightly proud of the front face)
    yf = -(d["body_d0"] + (d["body_d1"] - d["body_d0"]) * ((d["disp_z"] - zb0) / d["body_len"])) / 2
    parts.append(("display", *box(0.0, yf, d["disp_z"] + d["disp_h"] / 2, d["disp_w"], d["disp_depth"] * 2, d["disp_h"]),
                  "display", "body"))

    # --- volume label ridge (thin white bar below the display, purely cosmetic)
    parts.append(("label_ridge", *box(0.0, yf, d["disp_z"] - 0.004, d["disp_w"], 0.0006, 0.0025), "white", "body"))

    # ============ plunger (moving link) ============
    zp0 = zb1 + 0.004
    parts.append(("plunger_shaft", *lathe([(d["plunger_r"], zp0 - 0.012), (d["plunger_r"], zp0 + d["plunger_len"])],
                                           32, cx=d["plunger_x"]), "white", "plunger"))
    zbtn = zp0 + d["plunger_len"]
    parts.append(("plunger_button", *lathe([(d["plunger_r"] + 0.0005, zbtn - 0.0005),
                                             (d["button_r"] - 0.0015, zbtn),
                                             (d["button_r"], zbtn + 0.0015),
                                             (d["button_r"], zbtn + d["button_h"] - 0.0015),
                                             (d["button_r"] - 0.0015, zbtn + d["button_h"])],
                                            40, cx=d["plunger_x"]), "blue", "plunger"))

    # ============ tip ejector (moving link) ============
    ex = d["ejector_x"]
    parts.append(("ejector_rod", *lathe([(d["ejector_r"], d["ejector_sleeve_z1"] - 0.002),
                                          (d["ejector_r"], d["ejector_btn_z"])], 24, cx=ex), "blue", "ejector"))
    # side guide block that houses the rod along the body
    parts.append(("ejector_guide", *box(ex - 0.001, 0.0, (zb0 + d["ejector_btn_z"]) / 2 - 0.02,
                                        0.007, 0.010, d["ejector_btn_z"] - zb0 - 0.06), "white", "body"))
    zeb = d["ejector_btn_z"]
    parts.append(("ejector_button", *lathe([(d["ejector_r"], zeb - 0.001), (d["ejector_btn_r"] - 0.001, zeb),
                                             (d["ejector_btn_r"], zeb + 0.001),
                                             (d["ejector_btn_r"], zeb + d["ejector_btn_h"] - 0.001),
                                             (d["ejector_btn_r"] - 0.0015, zeb + d["ejector_btn_h"])],
                                            36, cx=ex + 0.0025), "blue", "ejector"))
    # sleeve around the shaft near the bottom (pushes the disposable tip off)
    parts.append(("ejector_sleeve", *lathe([(d["shaft_r1"] - 0.0005, d["ejector_sleeve_z0"]),
                                             (d["ejector_sleeve_r"], d["ejector_sleeve_z0"] + 0.004),
                                             (d["ejector_sleeve_r"], d["ejector_sleeve_z1"])], 40), "blue", "ejector"))
    # small arm connecting sleeve to rod
    parts.append(("ejector_arm", *box(ex / 2, 0.0, d["ejector_sleeve_z1"] - 0.0015, ex + 0.003, 0.005, 0.003),
                  "blue", "ejector"))
    return parts


# joint travel (metres, along -Z)
JOINTS = {
    "plunger": dict(range=(-0.014, 0.0), stiffness=350.0, damping=0.4),   # ~14 mm stroke, spring return
    "ejector": dict(range=(-0.008, 0.0), stiffness=500.0, damping=0.4),
}
TOTAL_MASS = 0.115  # kg (typical 10-100 µL single channel pipette)
LINK_MASS = {"body": 0.100, "plunger": 0.010, "ejector": 0.005}
TOTAL_LENGTH = D["body_z0"] + D["body_len"] + 0.004 + D["plunger_len"] + D["button_h"]

if __name__ == "__main__":
    for name, v, f, m, g in build_parts():
        print(f"{name:16s} {len(v):6d} verts {len(f):6d} tris  mat={m:8s} link={g}")
    print("total length %.1f mm" % (TOTAL_LENGTH * 1000))
