# Iris clamp — simulation asset (Blender · MuJoCo · Isaac Lab)

Self-adjusting, self-rotating iris clamp: one input rotation closes the iris
on a bottle cap, then (via a planetary differential and a torque clutch) rotates
the whole housing and unscrews the cap. Everything below is generated from
`params.py`, so change a dimension there and rebuild.

```
python build_meshes.py     # meshes/*.stl + iris_clamp_visual.glb   (needs trimesh, shapely, mapbox_earcut)
python build_mujoco.py     # mujoco/iris_clamp.xml, bottle_cap.xml, scene.xml
python build_urdf.py       # isaac/iris_clamp.urdf
blender -b -P blender/build_iris_clamp_blender.py -- --out assets/iris-clamp   # .blend + .glb rig
python mujoco/demo_unscrew.py [--view] [--video out.mp4]                        # verified run
```

Conventions: metres, Z = clamp axis, iris plane at z = 0, mechanism stacked on +Z,
origin on the axis. glTF export is +Y up like the reagent-jar kit. Colours: black
housing / carrier / planets, gold iris / cam ring / ring gear / sun; bottle amber, cap red.

## Parts and joints (identical tree in MJCF, URDF and Blender)

| body | parent | joint | meaning |
|---|---|---|---|
| `mount` | world / robot flange | `mount_z` slide (optional) | tool interface, axial compliance |
| `sun` | mount | `sun_input` hinge | **the single input**; motor, torque-limited |
| `body` (carrier + housing + pivots + clutch) | mount | `body_yaw` hinge, frictionloss = T_release | rotates the whole clamp |
| `cam_ring` (+ ring gear) | body | `cam` hinge | closes the iris |
| `blade_0..5` | body | hinges at R = 55 mm, range 0–76° | **collision boxes**, slaved to `cam` |
| `planet_0..2` | body | hinges (visual) | mesh the sun |

Couplings: `N_s·q_sun + N_r·q_cam − N_s·q_body = 0` (planetary), `q_blade = −q_cam`
(cam profile, gain 1). Aperture inradius `r = R_pivot · cos(q_blade)`: 55 mm open → 13 mm closed.

## MuJoCo (physically closed loop — the transition is not scripted)

`mujoco/iris_clamp.xml` implements the differential as a fixed tendon held at zero by an
equality, the clutch as `frictionloss` on `body_yaw`, the input limiter as the motor's
`forcerange`. The sun is a child of the mount (grounded motor), so the drive reaction
does not leak into the carrier. Blade boxes collide with the cap (contype/conaffinity
bits keep blades from colliding with each other).

`mujoco/bottle_cap.xml`: the cap is a **free body** welded to an invisible thread
follower (hinge + slide with a screw equality, thread friction as `frictionloss`).
`demo_unscrew.py` disables the two thread equalities once the cap has done
`THREAD_TURNS` turns — after that the cap is a plain rigid body that the blades keep
holding and the mount lifts away. Swap the bottle for any object: give it
`contype="1" conaffinity="2"` and a `thread_follower`; to add a bottle from the
reagent-jar kit, keep the cap radius within 13–55 mm.

Verified sequence (`demo_unscrew.py`, τ = 0.45 N m): iris closes in 0.3 s, contact at
Ø 28.0 mm, clutch slips at T_release = 0.15 N m, housing turns 1:1 with the cap,
cap lifts 2.5 mm/turn, thread released after 2 turns, cap carried away. Timestep 0.5 ms,
`implicitfast`, elliptic cones.

Physics note: once the ring gear is blocked *against the housing*, the planetary is locked
and the housing turns at the input speed (1:1). The 0.25 ratio in the concept text applies
when the ring gear is held to the fixed frame instead; change `params.py` and the tendon
coefficients if you want that architecture.

## Isaac Lab (PhysX)

PhysX articulations have no tendon/differential constraint. `isaac/iris_clamp.urdf`
exposes the three real joints plus `<mimic>` joints for blades and planets (Isaac Sim ≥ 4.5
imports mimic joints as PhysX mimic constraints; set `fix_base=True`, `merge_fixed_joints=False`
in `UrdfConverterCfg`). `isaac/planetary_clutch_controller.py` closes the loop: from one
input angle it sets the `cam` and `body_yaw` targets, switching when the **measured cam
joint effort** exceeds T_release — the same mechanical contact signal as the real device.
Blades are collision boxes, so a cap modelled as a rigid body with a D6/revolute+prismatic
joint (or a PhysX screw via `physxJoint` + `DriveAPI`) is gripped and turned by contact.

## Blender rig

`blender/build_iris_clamp_blender.py` imports the STLs, parents them as above, assigns
materials, and adds drivers: `iris_clamp["theta_in"]` (degrees) drives sun, cam ring, blades,
planets, housing, cap rotation and cap lift with the same two-phase law; `["cap_radius"]`
sets where the iris stops. Each object carries joint metadata as custom properties
(exported to glTF `extras`). A demo action (0 → 1440° over 240 frames) is saved.
