"""Blender 4.x / 5.x : build the iris clamp as a rigged, animatable object.

Run from the repo folder:
    blender -b -P blender/build_iris_clamp_blender.py -- --out assets/iris-clamp
or paste into the Scripting tab (then set OUT below).

What it makes
  * one object per rigid part, parented exactly like the MJCF/URDF tree
    (body > cam_ring, planets, blades ; sun separate, mount root)
  * every joint axis is the local Z of its object (origin on the axis)
  * black / gold PBR materials
  * a rig: custom property  mount["theta_in"] (degrees) drives the whole
    mechanism with the same two-phase logic as the HTML/MuJoCo model,
    so scrubbing one slider closes the iris and then rotates the housing.
    mount["cap_radius"] sets the object diameter the iris will stop at.
  * custom properties on each part (joint, axis, range, coupling) so a
    USD/URDF exporter or your own script can rebuild the articulation.
  * saves iris_clamp.blend and exports iris_clamp.glb (+Y up, metres).
"""
import bpy, math, os, sys

# ---- locate repo + meshes --------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else bpy.path.abspath("//")
REPO = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, REPO)
import params as P
MESHES = os.path.join(REPO, "meshes")
argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
OUT = argv[argv.index("--out") + 1] if "--out" in argv else os.path.join(REPO, "blender", "out")
os.makedirs(OUT, exist_ok=True)

# ---- clean scene -----------------------------------------------------------
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.unit_settings.system = "METRIC"; scene.unit_settings.scale_length = 1.0

def material(name, rgb, metallic=1.0, rough=0.25):
    m = bpy.data.materials.new(name); m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*rgb, 1)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = rough
    return m
GOLD = material("IrisClamp_Gold", (0.83, 0.65, 0.24))
BLACK = material("IrisClamp_Black", (0.02, 0.022, 0.025), 0.9, 0.35)
RED = material("Bottle_Cap_Red", (0.72, 0.06, 0.05), 0.0, 0.5)
AMBER = material("Bottle_Amber", (0.82, 0.48, 0.11), 0.0, 0.05)
if hasattr(AMBER, "blend_method"):
    try: AMBER.blend_method = "BLEND"
    except Exception: pass
AMBER.node_tree.nodes["Principled BSDF"].inputs["Alpha"].default_value = 0.45

def import_stl(name, file, mat, parent=None, loc=(0, 0, 0), rot_z=0.0, props=None):
    path = os.path.join(MESHES, file)
    if hasattr(bpy.ops.wm, "stl_import"):
        bpy.ops.wm.stl_import(filepath=path)
    else:
        bpy.ops.import_mesh.stl(filepath=path)
    ob = bpy.context.selected_objects[0]
    ob.name = name; ob.data.name = name
    ob.data.materials.append(mat)
    for p in ob.data.polygons: p.use_smooth = False
    ob.location = loc; ob.rotation_euler = (0, 0, rot_z)
    if parent: ob.parent = parent
    for k, v in (props or {}).items(): ob[k] = v
    return ob

# ---- hierarchy -------------------------------------------------------------
mount = bpy.data.objects.new("iris_clamp", None); mount.empty_display_type = "PLAIN_AXES"; mount.empty_display_size = 0.02
scene.collection.objects.link(mount)
mount["theta_in"] = 0.0
mount["cap_radius"] = P.CAP_R
mount["units"] = "m, Z = clamp axis, iris plane z=0"
mount["joint:mount_z"] = "slide z (optional, tool compliance)"
mount.id_properties_ui("theta_in").update(min=0.0, max=3600.0, description="Input shaft angle (deg) - drives everything")
mount.id_properties_ui("cap_radius").update(min=0.005, max=0.05, description="Radius of the object the iris will stop on (m)")

sun = import_stl("sun", "sun.stl", GOLD, mount, props={"joint": "hinge", "axis": "Z", "parent": "iris_clamp", "actuator": "input torque"})
body = import_stl("body", "body.stl", BLACK, mount, props={"joint": "hinge", "axis": "Z", "parent": "iris_clamp", "clutch_frictionloss_Nm": P.T_RELEASE})
cam = import_stl("cam_ring", "cam_ring.stl", GOLD, body, props={"joint": "hinge", "axis": "Z", "parent": "body",
                 "coupling": f"{P.N_SUN}*q_sun + {P.N_RING}*q_cam - {P.N_SUN}*q_body = 0"})
planets, blades = [], []
for i in range(P.N_PLANETS):
    a = 2 * math.pi * i / P.N_PLANETS
    planets.append(import_stl(f"planet_{i}", "planet.stl", BLACK, body,
                              ((P.R_SUN + P.R_PLANET) * math.cos(a), (P.R_SUN + P.R_PLANET) * math.sin(a), 0),
                              props={"joint": "hinge", "axis": "Z", "parent": "body", "coupling": "visual: q = -(Ns/Np)*(q_sun - q_body)"}))
for i in range(P.N_BLADES):
    a = 2 * math.pi * i / P.N_BLADES
    blades.append(import_stl(f"blade_{i}", "blade.stl", GOLD, body,
                             (P.R_PIVOT * math.cos(a), P.R_PIVOT * math.sin(a), P.BLADE_Z0 + i * P.BLADE_T), a,
                             props={"joint": "hinge", "axis": "Z", "parent": "body", "range_deg": [0, math.degrees(P.BLADE_MAX)],
                                    "coupling": f"q_blade = {-P.CAM_TO_BLADE_GAIN}*q_cam", "collision": "box"}))

# demo bottle (own root, so it can be deleted or swapped for the reagent jars)
zb = -(P.CAP_H / 2 - (P.N_BLADES * P.BLADE_T) / 2) - P.BOTTLE_H
bottle = import_stl("bottle", "bottle.stl", AMBER, None, (0, 0, zb))
capob = import_stl("cap", "cap.stl", RED, bottle, (0, 0, P.BOTTLE_H), props={"joint": "screw", "pitch_m": P.THREAD_PITCH, "turns": P.THREAD_TURNS})

# ---- drivers: one input angle -> two-phase motion --------------------------
KIN = f'''
import math
def iris_kin(theta_deg, cap_r, what, i=0):
    """Same law as the HTML/MuJoCo model. theta in deg, returns deg (or m for cap lift)."""
    th = math.radians(theta_deg)
    RP, NS, NR, G = {P.R_PIVOT}, {P.N_SUN}, {P.N_RING}, {P.CAM_TO_BLADE_GAIN}
    a_c = math.acos(max(-1.0, min(1.0, cap_r / RP)))          # blade angle at contact
    th_c = a_c / G * NR / NS                                      # input angle at contact (carrier held)
    if th <= th_c:
        cam, body = -th * NS / NR, 0.0
    else:
        cam, body = -th_c * NS / NR, th - th_c                    # ring locked to housing -> 1:1 (physical)
    if what == "sun":    return theta_deg
    if what == "cam":    return math.degrees(cam)
    if what == "body":   return math.degrees(body)
    if what == "blade":  return math.degrees(-G * cam)
    if what == "planet": return math.degrees(-(NS / {P.N_PLANET}) * (th - body))
    if what == "cap":    return math.degrees(body)
    if what == "lift":   return body / (2 * math.pi) * {P.THREAD_PITCH}
    return 0.0
'''
txt = bpy.data.texts.new("iris_clamp_drivers.py"); txt.write(KIN); txt.use_module = True
exec(KIN, bpy.app.driver_namespace)          # register in the driver namespace for this session

def add_driver(ob, what, i=0, path="rotation_euler", index=2):
    fc = ob.driver_add(path, index)
    d = fc.driver; d.type = "SCRIPTED"
    for var, prop in (("theta", '["theta_in"]'), ("capr", '["cap_radius"]')):
        v = d.variables.new(); v.name = var; v.type = "SINGLE_PROP"
        v.targets[0].id = mount; v.targets[0].data_path = prop
    d.expression = f'radians(iris_kin(theta, capr, "{what}", {i}))' if what != "lift" else f'iris_kin(theta, capr, "lift")'
    return fc

add_driver(sun, "sun"); add_driver(cam, "cam"); add_driver(body, "body")
for i, pl in enumerate(planets): add_driver(pl, "planet", i)
for i, bl in enumerate(blades):
    fc = add_driver(bl, "blade", i)
    a = 2 * math.pi * i / P.N_BLADES
    fc.driver.expression = f'{a} + radians(iris_kin(theta, capr, "blade", {i}))'
add_driver(capob, "cap")
fc = add_driver(capob, "lift", path="location", index=2); fc.driver.expression = f'{P.BOTTLE_H} + iris_kin(theta, capr, "lift")'
fc = add_driver(mount, "lift", path="location", index=2); fc.driver.expression = 'iris_kin(theta, capr, "lift")'

# ---- a demo action: theta_in 0 -> 1440 over 240 frames -----------------------
mount["theta_in"] = 0.0; mount.keyframe_insert('["theta_in"]', frame=1)
mount["theta_in"] = 1440.0; mount.keyframe_insert('["theta_in"]', frame=240)
scene.frame_start, scene.frame_end = 1, 240
try:
    for fcu in mount.animation_data.action.fcurves:
        for kp in fcu.keyframe_points: kp.interpolation = "LINEAR"
except Exception:
    pass  # slotted actions (Blender >= 4.4) expose fcurves differently; ease-in/out is fine too

# ---- save + export ------------------------------------------------------------
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "iris_clamp.blend"))
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, "iris_clamp.glb"), export_format="GLB",
                          export_yup=True, export_apply=True, export_animations=True, export_extras=True)
print("saved", os.path.join(OUT, "iris_clamp.blend"), "and iris_clamp.glb")
