"""Run the full sequence in MuJoCo and report each phase.

    python demo_unscrew.py            # headless, prints a log
    python demo_unscrew.py --view     # opens the interactive viewer
    python demo_unscrew.py --video out.mp4   (needs imageio-ffmpeg)

Sequence produced by ONE input torque on `sun_input`:
  1. blades close (cam ring turns -1/3 of the sun),
  2. contact with the cap, cam ring stalls, torque builds up,
  3. carrier clutch (frictionloss on body_yaw) slips, housing rotates,
  4. cap spins & lifts on the thread equality,
  5. after THREAD_TURNS the thread equalities are switched off -> cap free,
  6. the mount lifts the clamp with the cap still gripped.
"""
import sys, os, math, argparse
import numpy as np
import mujoco

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import params as P

ap = argparse.ArgumentParser()
ap.add_argument("--view", action="store_true")
ap.add_argument("--video", default=None)
ap.add_argument("--torque", type=float, default=0.45)
ap.add_argument("--duration", type=float, default=8.0)
args = ap.parse_args()

HERE = os.path.dirname(os.path.abspath(__file__))
model = mujoco.MjModel.from_xml_path(os.path.join(HERE, "scene.xml"))
data = mujoco.MjData(model)

jid = lambda n: model.joint(n).id
q = lambda n: data.qpos[model.jnt_qposadr[jid(n)]]
eq_thread = model.equality("thread_screw").id
eq_weld = model.equality("thread_weld").id
act_torque = model.actuator("input_torque").id
act_lift = model.actuator("mount_lift").id

phase, log_t, released = "cierre", 0.0, False
alpha_prev = 0.0
frames = []
renderer = mujoco.Renderer(model, 480, 720) if args.video else None
viewer = None
if args.view:
    import mujoco.viewer
    viewer = mujoco.viewer.launch_passive(model, data)

def state():
    aperture = 2 * P.R_PIVOT * math.cos(q("blade_0"))
    return dict(t=data.time, sun=math.degrees(q("sun_input")), cam=math.degrees(q("cam")),
                yaw=math.degrees(q("body_yaw")), blade=math.degrees(q("blade_0")),
                aperture_mm=aperture * 1e3, cap_turns=q("cap_spin") / (2 * math.pi),
                cap_lift_mm=q("cap_lift") * 1e3, cap_z=data.body("cap").xpos[2],
                ncon=data.ncon)

print(f"{'t':>5} {'phase':<12} {'sun°':>7} {'cam°':>7} {'yaw°':>7} {'apert mm':>9} {'cap turns':>9} {'lift mm':>8}")
while data.time < args.duration:
    data.ctrl[act_torque] = args.torque
    # the clamp must follow the cap up the thread (a real tool is held with axial compliance);
    # here the mount tracks the expected thread travel, then lifts the free cap away
    if not released:
        data.ctrl[act_lift] = P.THREAD_PITCH * max(0.0, q("cap_spin") / (2 * math.pi))
    else:
        data.ctrl[act_lift] = min(0.12, P.THREAD_PITCH * P.THREAD_TURNS + 0.12 * (data.time - t_release) / 1.5)

    # thread release: the cap has travelled the whole thread
    if not released and q("cap_spin") / (2 * math.pi) >= P.THREAD_TURNS:
        data.eq_active[eq_thread] = 0
        data.eq_active[eq_weld] = 0
        released, t_release = True, data.time
        phase = "tapa libre"
        print(f"      >>> t={data.time:.2f}s rosca agotada: equality thread_screw + thread_weld desactivadas, la tapa es un cuerpo libre")

    mujoco.mj_step(model, data)

    s = state()
    if phase == "cierre" and s["ncon"] > 0 and abs(q("blade_0") - alpha_prev) < 1e-5:
        phase = "contacto"
        print(f"      >>> t={s['t']:.2f}s contacto: {s['ncon']} contactos, apertura {s['aperture_mm']:.1f} mm, cam bloqueado")
    if phase == "contacto" and abs(q("body_yaw")) > math.radians(3):
        phase = "rotacion"
        print(f"      >>> t={s['t']:.2f}s embrague deslizando: el cuerpo gira (T_release={P.T_RELEASE} N m)")
    alpha_prev = q("blade_0")

    if data.time - log_t >= 0.25:
        log_t = data.time
        print(f"{s['t']:5.2f} {phase:<12} {s['sun']:7.1f} {s['cam']:7.1f} {s['yaw']:7.1f} {s['aperture_mm']:9.1f} {s['cap_turns']:9.2f} {s['cap_lift_mm']:8.2f}")
    if renderer and int(data.time * 60) > len(frames):
        renderer.update_scene(data, camera=-1)
        frames.append(renderer.render().copy())
    if viewer:
        viewer.sync()
        if not viewer.is_running():
            break

s = state()
ok = released and s["cap_z"] > 0.03
print("\nRESULTADO:", "tapa desenroscada y elevada" if ok else "no se ha completado", f"(cap z = {s['cap_z']*1e3:.1f} mm, vueltas = {s['cap_turns']:.2f})")
if args.video:
    import imageio
    imageio.mimwrite(args.video, frames, fps=60)
    print("video:", args.video)
