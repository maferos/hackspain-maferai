"""Build one STL per rigid part of the iris clamp + a hierarchical GLB.

    python build_meshes.py            -> meshes/*.stl, iris_clamp_visual.glb

Every part mesh is expressed in the frame of its own joint (origin on the
joint axis, Z along the axis) so the same files are used unchanged by the
MJCF, the URDF and the Blender script.
"""
import math, os
import numpy as np
import trimesh
from shapely.geometry import Polygon, Point
import params as P

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "meshes")
os.makedirs(OUT, exist_ok=True)


def gear_profile(n, r, internal=False):
    """Simple trapezoid-tooth profile (visual only)."""
    add = P.MODULE * 0.9
    pts = []
    for i in range(n * 4):
        a = 2 * math.pi * i / (n * 4)
        tooth = i % 4 in (1, 2)
        rr = (r - add if tooth else r) if internal else (r + add if tooth else r)
        pts.append((rr * math.cos(a), rr * math.sin(a)))
    return Polygon(pts)


def ring(ro, ri, h, z0=0.0, res=96):
    poly = Point(0, 0).buffer(ro, res).difference(Point(0, 0).buffer(ri, res))
    m = trimesh.creation.extrude_polygon(poly, h)
    m.apply_translation([0, 0, z0])
    return m


def extrude(poly, h, z0=0.0):
    m = trimesh.creation.extrude_polygon(poly, h)
    m.apply_translation([0, 0, z0])
    return m


parts = {}

# --- carrier / body: front ring, 3 struts, carrier plate, planet pins, blade pins, top ring
body = [ring(P.HOUSING_R, P.HOUSING_RI, P.Z_CAM - 0.002, -0.004)]
for i in range(3):
    a = 2 * math.pi * i / 3 + math.pi / 3
    strut = trimesh.creation.box([0.010, 0.014, P.Z_TOP - P.Z_CAM])
    strut.apply_transform(trimesh.transformations.rotation_matrix(a, [0, 0, 1]))
    r = P.R_RING + 0.018
    strut.apply_translation([r * math.cos(a), r * math.sin(a), (P.Z_TOP + P.Z_CAM) / 2])
    body.append(strut)
body.append(ring(P.HOUSING_R, P.R_RING + 0.012, 0.004, P.Z_CAM - 0.002))          # shoulder
body.append(ring(P.R_RING + 0.010, 0.006, P.CARRIER_T, P.Z_CARRIER))                # carrier plate
body.append(ring(P.R_RING + 0.024, P.R_RING + 0.010, P.CLUTCH_T, P.Z_CLUTCH))       # clutch ring
body.append(ring(P.R_RING + 0.024, P.R_RING + 0.010, 0.004, P.Z_TOP - 0.004))       # top ring
for i in range(P.N_PLANETS):
    a = 2 * math.pi * i / P.N_PLANETS
    pin = trimesh.creation.cylinder(0.0025, P.Z_CARRIER - P.Z_GEARS + 0.004, sections=16)
    pin.apply_translation([(P.R_SUN + P.R_PLANET) * math.cos(a), (P.R_SUN + P.R_PLANET) * math.sin(a),
                           (P.Z_GEARS + P.Z_CARRIER + 0.004) / 2 - 0.002])
    body.append(pin)
for i in range(P.N_BLADES):
    a = 2 * math.pi * i / P.N_BLADES
    pin = trimesh.creation.cylinder(0.002, 0.020, sections=16)
    pin.apply_translation([P.R_PIVOT * math.cos(a), P.R_PIVOT * math.sin(a), 0.006])
    body.append(pin)
parts["body"] = trimesh.util.concatenate(body)

# --- cam ring + ring gear (one rigid part, joint on the axis)
cam = [ring(P.R_PIVOT + 0.004, P.R_PIVOT - 0.014, P.CAM_T, P.Z_CAM),
       ring(P.R_PIVOT - 0.006, P.R_RING + 0.008, 0.003, P.Z_CAM + P.CAM_T),          # web
       extrude(Point(0, 0).buffer(P.R_RING + 0.008, 96).difference(gear_profile(P.N_RING, P.R_RING, True)),
               P.GEAR_THICK, P.Z_GEARS)]
parts["cam_ring"] = trimesh.util.concatenate(cam)

# --- sun gear + input shaft
sun = [extrude(gear_profile(P.N_SUN, P.R_SUN), P.GEAR_THICK, P.Z_GEARS),
       trimesh.creation.cylinder(0.004, P.Z_TOP + 0.030 - P.Z_GEARS, sections=24)]
sun[1].apply_translation([0, 0, (P.Z_TOP + 0.030 + P.Z_GEARS) / 2])
parts["sun"] = trimesh.util.concatenate(sun)

# --- one planet gear (instanced 3x)
parts["planet"] = extrude(gear_profile(P.N_PLANET, P.R_PLANET).difference(Point(0, 0).buffer(0.003, 16)),
                          P.GEAR_THICK, P.Z_GEARS)

# --- one blade, in its pivot frame: inner (gripping) face is the plane x=0, slat along +y
blade = trimesh.creation.box([P.BLADE_W, P.BLADE_LEN, P.BLADE_T])
blade.apply_translation([P.BLADE_W / 2, P.BLADE_LEN / 2, P.BLADE_T / 2])
# rounded tip
tip = trimesh.creation.cylinder(P.BLADE_W / 2, P.BLADE_T, sections=24)
tip.apply_translation([P.BLADE_W / 2, P.BLADE_LEN, P.BLADE_T / 2])
parts["blade"] = trimesh.util.concatenate([blade, tip])

# --- demo bottle + cap (metres, origin at bottle base)
parts["bottle"] = trimesh.util.concatenate([
    trimesh.creation.cylinder(P.BOTTLE_R, P.BOTTLE_H, sections=64).apply_translation([0, 0, P.BOTTLE_H / 2]),
    trimesh.creation.cylinder(P.NECK_R, P.CAP_H, sections=48).apply_translation([0, 0, P.BOTTLE_H + P.CAP_H / 2])])
cap = trimesh.creation.cylinder(P.CAP_R, P.CAP_H, sections=48).apply_translation([0, 0, P.CAP_H / 2])
parts["cap"] = cap

for name, m in parts.items():
    m.export(os.path.join(OUT, f"{name}.stl"))

# --- hierarchical GLB (visual reference; Blender script rebuilds the same tree)
scene = trimesh.Scene()
GOLD, BLACK, RED, AMBER = [212, 166, 60, 255], [23, 25, 28, 255], [216, 50, 44, 255], [208, 122, 28, 140]
def add(name, mesh, color, parent=None, T=None):
    m = mesh.copy(); m.visual = trimesh.visual.ColorVisuals(m, face_colors=color)
    scene.add_geometry(m, node_name=name, geom_name=name, parent_node_name=parent, transform=T)
R = trimesh.transformations.rotation_matrix
Tr = trimesh.transformations.translation_matrix
add("body", parts["body"], BLACK)
add("cam_ring", parts["cam_ring"], GOLD, "body")
add("sun", parts["sun"], GOLD, "body")
for i in range(P.N_PLANETS):
    a = 2 * math.pi * i / P.N_PLANETS
    add(f"planet_{i}", parts["planet"], BLACK, "body", Tr([(P.R_SUN + P.R_PLANET) * math.cos(a), (P.R_SUN + P.R_PLANET) * math.sin(a), 0]))
for i in range(P.N_BLADES):
    a = 2 * math.pi * i / P.N_BLADES
    T = Tr([P.R_PIVOT * math.cos(a), P.R_PIVOT * math.sin(a), P.BLADE_Z0 + i * P.BLADE_T]) @ R(a, [0, 0, 1])
    add(f"blade_{i}", parts["blade"], GOLD, "body", T)
add("bottle", parts["bottle"], AMBER, None, Tr([0, 0, -(P.BOTTLE_H + P.CAP_H / 2)]))
add("cap", parts["cap"], RED, "bottle", Tr([0, 0, P.BOTTLE_H]))
scene.export(os.path.join(os.path.dirname(OUT), "iris_clamp_visual.glb"))
print("wrote", sorted(parts), "and iris_clamp_visual.glb")
