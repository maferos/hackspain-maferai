"""Planetary differential + torque clutch for Isaac Lab (PhysX has no tendon
equalities, so the coupling between the three real DOF is closed here).

Inputs per step
    theta_in       : input-shaft angle command (rad), the single coordinate
    cam_effort     : measured effort on the `cam` joint (N m)  -> from
                     articulation.root_physx_view.get_measured_joint_forces()
                     or articulation.data.applied_torque[..., cam_idx]
Outputs
    cam_target, body_target : position targets for joints `cam` and `body_yaw`

Law (same as the MJCF):  N_s*q_sun + N_r*q_cam - N_s*q_body = 0
  phase 1  carrier held      -> q_cam  = -(N_s/N_r) * theta_in
  contact  |cam effort| >= T_release  (the blades are blocked by the object)
  phase 2  ring locked       -> q_cam frozen, q_body = theta_in - theta_contact

Usage sketch (Isaac Lab):
    drive = PlanetaryClutch()
    cam_i  = robot.find_joints("cam")[0][0]
    yaw_i  = robot.find_joints("body_yaw")[0][0]
    ...
    eff = robot.data.applied_torque[:, cam_i]          # (num_envs,)
    cam_t, yaw_t = drive.step(theta_cmd, eff)           # tensors (num_envs,)
    targets = robot.data.joint_pos_target.clone()
    targets[:, cam_i] = cam_t; targets[:, yaw_i] = yaw_t
    robot.set_joint_position_target(targets)
Use a stiff position drive on `cam` (stiffness ~ 50, damping ~ 2) with
`max_effort` = T_release * N_r / N_s so the drive itself saturates like the
real gear train, and a compliant drive (or effort mode) on `body_yaw`.
The URDF gives `body_yaw` a joint friction of T_release, so with a zero
position target the housing stays put until the controller moves it.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import params as P

try:
    import torch
except ImportError:      # allow import without torch for docs/tests
    torch = None


class PlanetaryClutch:
    def __init__(self, num_envs=1, t_release=P.T_RELEASE, device="cpu"):
        self.ratio = P.N_SUN / P.N_RING
        self.t_release = t_release
        z = torch.zeros(num_envs, device=device) if torch else 0.0
        self.contact = (z > 1) if torch else False   # bool per env
        self.theta_c = z.clone() if torch else 0.0
        self.cam_hold = z.clone() if torch else 0.0

    def reset(self, env_ids=None):
        if torch:
            ids = slice(None) if env_ids is None else env_ids
            self.contact[ids] = False; self.theta_c[ids] = 0.0; self.cam_hold[ids] = 0.0
        else:
            self.contact, self.theta_c, self.cam_hold = False, 0.0, 0.0

    def step(self, theta_in, cam_effort):
        """theta_in, cam_effort: tensors (num_envs,) or floats. Returns (cam_target, body_target)."""
        if torch and torch.is_tensor(theta_in):
            newly = (~self.contact) & (cam_effort.abs() >= self.t_release)
            self.contact |= newly
            self.theta_c = torch.where(newly, theta_in, self.theta_c)
            self.cam_hold = torch.where(newly, -self.ratio * theta_in, self.cam_hold)
            cam = torch.where(self.contact, self.cam_hold, -self.ratio * theta_in)
            body = torch.where(self.contact, theta_in - self.theta_c, torch.zeros_like(theta_in))
            return cam, body
        # scalar path
        if not self.contact and abs(cam_effort) >= self.t_release:
            self.contact, self.theta_c, self.cam_hold = True, theta_in, -self.ratio * theta_in
        if self.contact:
            return self.cam_hold, theta_in - self.theta_c
        return -self.ratio * theta_in, 0.0


if __name__ == "__main__":
    import math
    d = PlanetaryClutch()
    for th in [0.0, 1.0, 2.0, 3.0, 4.0, 5.0]:
        effort = 0.0 if th < 2.5 else 0.3          # pretend the blades hit something at ~2.5 rad
        print(f"theta_in={th:.1f}  cam={d.step(th, effort)[0]:+.3f}  body={d.step(th, effort)[1]:+.3f}")
