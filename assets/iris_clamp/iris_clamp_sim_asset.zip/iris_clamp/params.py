"""Single source of truth for the iris-clamp geometry (metres, radians).

Used by build_meshes.py (visual meshes), build_mujoco.py (MJCF) and
build_urdf.py (Isaac Lab).  Z is the clamp axis; the iris opening is at
z = 0 and the mechanism stacks upwards (+Z).  The clamp is mounted above
the bottle, so in a scene it is usually rotated 180 deg about X or simply
placed with its iris plane at the height of the cap.
"""
import math

# ---- gear train ----------------------------------------------------------
N_SUN, N_PLANET, N_RING = 20, 20, 60
MODULE = 0.0012                      # m per tooth (1.2 mm module)
R_SUN = MODULE * N_SUN / 2           # 0.012
R_PLANET = MODULE * N_PLANET / 2     # 0.012
R_RING = MODULE * N_RING / 2         # 0.036
N_PLANETS = 3
GEAR_THICK = 0.008
CAM_TO_BLADE_GAIN = 1.0              # blade angle = gain * cam-ring angle (cam profile slope)

# ---- iris -----------------------------------------------------------------
N_BLADES = 6
R_PIVOT = 0.055                      # blade pivot radius
BLADE_LEN = 0.062
BLADE_W = 0.012
BLADE_T = 0.0025
BLADE_Z0 = 0.0                       # z of the lowest blade
BLADE_MAX = math.radians(76)         # closes down to R_PIVOT*cos(76 deg) ~ 13 mm inradius
# aperture inradius as a function of blade angle:  r = R_PIVOT * cos(alpha)

# ---- housing stack (z from the iris plane) -------------------------------
Z_CAM = 0.018                        # cam ring bottom
CAM_T = 0.006
Z_GEARS = 0.030                      # sun / planet / ring gear bottom
Z_CARRIER = 0.042                    # carrier plate bottom
CARRIER_T = 0.006
Z_CLUTCH = 0.048                     # clutch friction ring
CLUTCH_T = 0.004
Z_TOP = 0.060                        # top of the housing / mount interface
HOUSING_R = R_PIVOT + 0.014          # 0.069 outer radius of the front ring
HOUSING_RI = R_PIVOT + 0.004

# ---- clutch / torque -----------------------------------------------------
T_RELEASE = 0.15                     # N m   carrier friction (clutch preload)
T_INPUT_MAX = 0.60                   # N m   input torque limiter
T_THREAD = 0.04                      # N m   friction of the bottle thread

# ---- demo bottle ----------------------------------------------------------
CAP_R = 0.014
CAP_H = 0.018
NECK_R = 0.011
THREAD_PITCH = 0.0025                # m per turn
THREAD_TURNS = 2.0                   # turns until the cap is free
BOTTLE_R = 0.026
BOTTLE_H = 0.080

# derived
ALPHA_CONTACT = math.acos(CAP_R / R_PIVOT)
