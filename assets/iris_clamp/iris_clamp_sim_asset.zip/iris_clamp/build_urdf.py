"""Write isaac/iris_clamp.urdf for Isaac Lab / Isaac Sim (PhysX articulation).

PhysX has no differential/tendon constraint, so the URDF exposes the three
real DOF (sun_input, cam, body_yaw) plus mimic joints for the blades
(blade_i = -gain * cam) and the planets (visual).  The planetary + clutch
behaviour is reproduced by isaac/planetary_clutch_controller.py, which
drives `cam` and `body_yaw` from ONE input angle using the measured cam
joint effort as the mechanical "contact detected" signal.
Collision: blade boxes + a cylinder for the housing; everything else visual.
"""
import math, os
import params as P

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "isaac"); os.makedirs(OUT, exist_ok=True)
M = "../meshes"


def link(name, mesh, mass, rgba, collision="", origin="0 0 0"):
    return f'''
  <link name="{name}">
    <inertial><origin xyz="0 0 {origin.split()[2]}"/><mass value="{mass}"/><inertia ixx="{mass*1e-4:.2e}" iyy="{mass*1e-4:.2e}" izz="{mass*1e-4:.2e}" ixy="0" ixz="0" iyz="0"/></inertial>
    <visual><geometry><mesh filename="{M}/{mesh}.stl"/></geometry><material name="{name}_m"><color rgba="{rgba}"/></material></visual>{collision}
  </link>'''


def joint(name, typ, parent, child, xyz="0 0 0", rpy="0 0 0", axis="0 0 1", limit="", mimic="", dyn='<dynamics damping="0.001" friction="0"/>'):
    return f'''
  <joint name="{name}" type="{typ}">
    <origin xyz="{xyz}" rpy="{rpy}"/><parent link="{parent}"/><child link="{child}"/><axis xyz="{axis}"/>{limit}{dyn}{mimic}
  </joint>'''


GOLD, BLACK = "0.83 0.65 0.24 1", "0.09 0.10 0.11 1"
out = ['<?xml version="1.0"?>\n<robot name="iris_clamp">',
       '  <link name="iris_clamp_mount"><inertial><mass value="0.3"/><inertia ixx="1e-4" iyy="1e-4" izz="1e-4" ixy="0" ixz="0" iyz="0"/></inertial></link>']
out.append(link("sun", "sun", 0.02, GOLD))
out.append(joint("sun_input", "continuous", "iris_clamp_mount", "sun", dyn='<dynamics damping="0.03"/>'))
housing_col = f'''
    <collision><origin xyz="0 0 {P.Z_TOP/2 + 0.006:.4f}"/><geometry><cylinder radius="{P.HOUSING_R:.4f}" length="{P.Z_TOP - 0.012:.4f}"/></geometry></collision>'''
out.append(link("body", "body", 0.35, BLACK, housing_col))
out.append(joint("body_yaw", "continuous", "iris_clamp_mount", "body", dyn=f'<dynamics damping="0.01" friction="{P.T_RELEASE}"/>'))
out.append(link("cam_ring", "cam_ring", 0.06, GOLD))
out.append(joint("cam", "revolute", "body", "cam_ring",
                 limit=f'<limit lower="{-P.BLADE_MAX/P.CAM_TO_BLADE_GAIN:.4f}" upper="0.0" effort="5" velocity="20"/>'))
for i in range(P.N_PLANETS):
    a = 2 * math.pi * i / P.N_PLANETS
    out.append(link(f"planet_{i}", "planet", 0.004, BLACK))
    out.append(joint(f"planet_{i}", "continuous", "body", f"planet_{i}",
                     xyz=f"{(P.R_SUN+P.R_PLANET)*math.cos(a):.5f} {(P.R_SUN+P.R_PLANET)*math.sin(a):.5f} 0",
                     mimic=f'<mimic joint="sun_input" multiplier="{-P.N_SUN/P.N_PLANET:.4f}" offset="0"/>'))
for i in range(P.N_BLADES):
    a = 2 * math.pi * i / P.N_BLADES
    col = f'''
    <collision><origin xyz="{P.BLADE_W/2:.5f} {P.BLADE_LEN/2:.5f} {P.BLADE_T/2:.5f}"/><geometry><box size="{P.BLADE_W:.4f} {P.BLADE_LEN:.4f} {P.BLADE_T:.4f}"/></geometry></collision>'''
    out.append(link(f"blade_{i}", "blade", 0.006, GOLD, col))
    out.append(joint(f"blade_{i}", "revolute", "body", f"blade_{i}",
                     xyz=f"{P.R_PIVOT*math.cos(a):.5f} {P.R_PIVOT*math.sin(a):.5f} {P.BLADE_Z0 + i*P.BLADE_T:.5f}", rpy=f"0 0 {a:.6f}",
                     limit=f'<limit lower="0" upper="{P.BLADE_MAX:.4f}" effort="5" velocity="20"/>',
                     mimic=f'<mimic joint="cam" multiplier="{-P.CAM_TO_BLADE_GAIN:.4f}" offset="0"/>'))
out.append("</robot>\n")
with open(os.path.join(OUT, "iris_clamp.urdf"), "w") as f:
    f.write("\n".join(out))
print("wrote isaac/iris_clamp.urdf")
